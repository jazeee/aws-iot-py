var config = {
    "thingName": 'Switch8266-east-v1',
    "endpointAddress": "a2arj82jdj67sr-ats.iot.us-east-1.amazonaws.com"
}

var AWS = require('aws-sdk');
var iotdata = new AWS.IotData({endpoint: config.endpointAddress});

exports.handler = async function (request, context) {
    if (request.directive.header.namespace === 'Alexa.Discovery' && request.directive.header.name === 'Discover') {
        log("DEBUG:", "Discover request",  JSON.stringify(request));
        handleDiscovery(request, context, "");
    }
    else if (request.directive.header.namespace === 'Alexa.PowerController') {
        const { name } = request.directive.header;
        if (name === 'TurnOn' || name === 'TurnOff') {
            log("DEBUG: ", `${name} Request data: `, JSON.stringify(request));
            await handlePowerControl(request, context);
        }
    }
    
    function setThingState(thingState, callback) {
        log("DEBUG", "setThingsState", "Starting");
        return new Promise((resolve, reject) => {
            iotdata.getThingShadow({
                thingName: config.thingName
            }, function(err, data) {
                log("DEBUG", "setThingsState", JSON.stringify(data));
                if (err) {
                    log("ERROR:", "setThingState", JSON.stringify(err));
                    return reject(err);
                } else {
                    var jsonPayload = JSON.parse(data.payload);
                    // var status = jsonPayload.state.reported.status;
                    // console.log('status: ' + status);
                    // var newStatus;
                    // if (status == 'ON') {
                    //     newStatus = 'OFF';
                    // } else {
                    //     newStatus = 'ON';
                    // }
                    var update = {
                        "state": {
                          "desired" : {
                                states: [{
                                    switchId: 200,
                                    relayState: thingState,
                                }],
                            }
                        }
                    };
                    iotdata.updateThingShadow({
                        payload: JSON.stringify(update),
                        thingName: config.thingName
                    }, function(err, data) {
                        if (err) {
                            return reject(err);
                        } else {
                            console.log(data);
                            return resolve(data);
                        }
                    });
                }
            });
        });
    };

    function handleDiscovery(request, context) {
        var payload = {
            "endpoints":
            [
                {
                    "endpointId": "demo_id",
                    "manufacturerName": "Jaz",
                    "friendlyName": "Living room light",
                    "description": "Smart Device Switch",
                    "displayCategories": ["SWITCH"],
                    "cookie": {
                        "key1": "arbitrary key/value pairs for skill to reference this endpoint.",
                        "key2": "There can be multiple entries",
                        "key3": "but they should only be used for reference purposes.",
                        "key4": "This is not a suitable place to maintain current endpoint state."
                    },
                    "capabilities":
                    [
                        {
                          "type": "AlexaInterface",
                          "interface": "Alexa",
                          "version": "3"
                        },
                        {
                            "interface": "Alexa.PowerController",
                            "version": "3",
                            "type": "AlexaInterface",
                            "properties": {
                                "supported": [{
                                    "name": "powerState"
                                }],
                                 "retrievable": true
                            }
                        }
                    ]
                }
            ]
        };
        var header = request.directive.header;
        header.name = "Discover.Response";
        log("DEBUG", "Discovery Response: ", JSON.stringify({ header: header, payload: payload }));
        context.succeed({ event: { header: header, payload: payload } });
    }

    function log(message, message1, message2) {
        console.log(message + message1 + message2);
    }

    async function handlePowerControl(request, context) {
        // get device ID passed in during discovery
        var requestMethod = request.directive.header.name;
        var responseHeader = request.directive.header;
        responseHeader.namespace = "Alexa";
        responseHeader.name = "Response";
        responseHeader.messageId = responseHeader.messageId + "-R";
        // get user token pass in request
        var requestToken = request.directive.endpoint.scope.token;
        var powerResult;
        log("Here: ", "Here", "here");
        try {
            if (requestMethod === "TurnOn") {
    
                // Make the call to your device cloud for control
                // powerResult = stubControlFunctionToYourCloud(endpointId, token, request);
                await setThingState(true);
                powerResult = "ON";
            }
            else if (requestMethod === "TurnOff") {
                // Make the call to your device cloud for control and check for success
                // powerResult = stubControlFunctionToYourCloud(endpointId, token, request);
                await setThingState(false);
                powerResult = "OFF";
            } else {
                return context.fail("Unknown method: " + requestMethod);
            }
        } catch (error) {
            log("ERROR: ", "setting thing state", error);
            return context.fail(error);
        }
        var contextResult = {
            "properties": [{
                "namespace": "Alexa.PowerController",
                "name": "powerState",
                "value": powerResult,
                "timeOfSample": "2017-09-03T16:20:50.52Z", //retrieve from result.
                "uncertaintyInMilliseconds": 50
            }]
        };
        var response = {
            context: contextResult,
            event: {
                header: responseHeader,
                endpoint: {
                    scope: {
                        type: "BearerToken",
                        token: requestToken
                    },
                    endpointId: "demo_id"
                },
                payload: {}
            }
        };
        log("DEBUG", "Alexa.PowerController ", JSON.stringify(response));
        context.succeed(response);
    }
};